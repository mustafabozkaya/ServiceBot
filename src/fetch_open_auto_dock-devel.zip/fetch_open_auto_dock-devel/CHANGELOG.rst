^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package fetch_open_auto_dock
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.2 (2019-02-13)
------------------
* [OPEN-4] update to package format 2 (`#2 <https://github.com/fetchrobotics/fetch_open_auto_dock/issues/2>`_)
  OPEN-4: update to package format 2
  OPEN-24: fetch_open_auto_dock does not build reliably the first time
* Fix package name reference (`#1 <https://github.com/fetchrobotics/fetch_open_auto_dock/issues/1>`_)
* Contributors: Alex Moriarty, Eric Relson

0.1.1 (2018-08-18)
------------------
* First release of auto dock
* Contributors: Russell Toris
