#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from time import time
import rospy
from geometry_msgs.msg import Twist

class Ekf():
    def __init__(self):
        rospy.init_node("EKF")
        self.rate =rospy.Rate(5)
        self.cmd_vel_v2 = 0
        self.cmd_vel_v3 = 0
        self.cmd_vel = Twist() 

        
        rospy.Subscriber("cmd_vel_v2", Twist, 
        self.vel_v2)
        rospy.Subscriber("cmd_vel_v3", Twist, 
        self.vel_v3)
        self.pub = rospy.Publisher(
            "cmd_vel", Twist, queue_size=10)
    
    def vel_v2(self,msg):
        self.cmd_vel_v2 = msg
        # print("v2")
        # print(self.cmd_vel_v2)
    
    def vel_v3(self,msg):
        self.cmd_vel_v3 = msg
        # print("v3")
        # print(self.cmd_vel_v3)
        # print("----------------")
    
    def toplama(self):

        return (self.cmd_vel_v2,self.cmd_vel_v3)
    
    def average(self):
        #vel2 ar_tag cmd verisidir vel3 line cmd verisidir
        vel2 = self.cmd_vel_v2
        vel3 = self.cmd_vel_v3
        if vel2 != 0 and vel3 !=0:
            if vel2.linear.x !=0 and vel3.linear.x !=0:
                print("iki hedef var")
                line_track = 0.5
                ar_tag = 0.5
            elif  vel2.linear.x ==0 and vel3.linear.x !=0:
                print("Line_Track")
                line_track = 1
                ar_tag = 0
            elif vel2.linear.x !=0 and vel3.linear.x ==0:
                print("Ar_tag")
                line_track = 0
                ar_tag = 1
            else:
                print("Hedef Yok")
                line_track = 0
                ar_tag = 0

            
            
            if (ar_tag + line_track)<1:
                rospy.loginfo("Hatalı değer")
                self.cmd_vel.linear.x = 0
                self.cmd_vel.linear.y = 0
                self.cmd_vel.linear.z = 0 
                self.cmd_vel.angular.x = 0
                self.cmd_vel.angular.y = 0
                self.cmd_vel.angular.z = 0
                self.pub.publish(self.cmd_vel)
                pass
            else:
                self.cmd_vel.linear.x = ((vel2.linear.x * ar_tag)+
                    vel3.linear.x*line_track)
                self.cmd_vel.linear.y = ((vel2.linear.y * ar_tag)+
                    vel3.linear.y*line_track)
                self.cmd_vel.linear.z = ((vel2.linear.z * ar_tag)+
                    vel3.linear.z*line_track)
                self.cmd_vel.angular.x = ((vel2.angular.x * ar_tag)+
                    vel3.angular.x *line_track)
                self.cmd_vel.angular.y = ((vel2.angular.y * ar_tag)+
                    vel3.angular.y*line_track)
                self.cmd_vel.angular.z = ((vel2.angular.z * ar_tag)+
                    vel3.angular.z*line_track)
                self.pub.publish(self.cmd_vel)
                
        else:
            self.cmd_vel.linear.x = 0
            self.cmd_vel.linear.y = 0
            self.cmd_vel.linear.z = 0 
            self.cmd_vel.angular.x = 0
            self.cmd_vel.angular.y = 0
            self.cmd_vel.angular.z = 0
            self.pub.publish(self.cmd_vel)
            
        
        

        return self.cmd_vel
            

        


if __name__ == "__main__":
    ekf=Ekf()
    while(not rospy.is_shutdown()):	
        
        v2 ,v3 = ekf.toplama()
        if v2 != 0 and v3 !=0:
            
            ekf.average()
            # print(v2.linear.x)
            # print(v3.linear.x)
            # differ = abs(v2.angular.z-v3.angular.z)
            # print(differ)
            # print(ekf.average()
        ekf.rate.sleep()
            
 


